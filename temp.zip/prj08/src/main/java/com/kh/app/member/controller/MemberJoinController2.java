package com.kh.app.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/member/join2")
public class MemberJoinController2 extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String memberId = req.getParameter("memberId");
		String memberPwd = req.getParameter("memberPwd");
		String memberPwdCheck = req.getParameter("memberPwdCheck");
		String memberNick = req.getParameter("memberNick");
		
		
		
//		if(!memberPwd.equals(memberPwdCheck)) {
//		회원가입 실패 => 디비에서 저장 안함	
//			화면 실패 띄우기
//		}else {
//			회원가입 성공 => 디비에서 저장
//			화면 성공 띄우기
//		}
		String pwd1 = req.getParameter("memberPwd");
		String pwd2 = req.getParameter("memberPwdCheck");
		String msg = "";
			if(pwd1.equals(pwd2)){
			msg = "성공";
			}else{
			msg = "실패";
			}
			req.setAttribute("x", msg);
		
		
		req.getRequestDispatcher("/WEB-INF/views/common/result.jsp").forward(req, resp);
	}
}
