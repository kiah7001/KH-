package com.kh.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/test")
public class TestController extends HttpServlet{
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String str = req.getParameter("num");
		System.out.println("이건 뭘까용~" + str);
		
		PrintWriter pw = resp.getWriter();
		pw.write("zzz");
	}
	
	
}
