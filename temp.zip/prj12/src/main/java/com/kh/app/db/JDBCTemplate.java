package com.kh.app.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCTemplate {

	
	public static Connection getConnection() throws Exception{
		//conn
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@192.168.40.44:1521:XE";
		String id = "C##KH";
		String pwd = "1234";
		Connection conn =  DriverManager.getConnection(url, id, pwd);
		conn.setAutoCommit(false);
		return conn;
		}
	
}
